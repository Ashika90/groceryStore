<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>about</title>
      <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/Style.css">

</head>
<body style="background-image: url(images/bg.jpg); background-repeat: no-repeat; background-size: cover; background-position: center;">
    <?php include 'header.php'; ?>

<section class="about">

    <div class="row">

        <div class="box">
            <img src="images/about-img-1.png" alt="">
            <h3>Why choose us?</h3>
            <p>Quality. Convenience. Variety. At [GroceryStore], we prioritize these pillars to ensure your 
                shopping experience is top-notch. From fresh produce to pantry staples, our platform offers 
                a wide selection to meet your needs. With reliable delivery and exceptional service, choose 
                us for an unmatched grocery experience.
            </p>
            <a href="contact.php" class="btn">contact us</a>
        </div>

        <div class="box">
            <img src="images/about-img-2.png" alt="">
            <h3>What we provide?</h3>
            <p>At [GroceryStore], we provide fresh fruits, crisp vegetables, wholesome grains, nutritious 
                dry fruits, and protein-rich pulses. With our wide variety of quality produce and pantry essentials,
                 we aim to cater to your dietary needs. Enjoy the convenience of online shopping with our reliable 
                 delivery service, ensuring freshness straight to your doorstep.
            </p>
            <a href="shop.php" class="btn">our shop</a>
        </div>

    </div>

</section>








    <?php include 'footer.php'; ?>


    <script src="js/script.js"></script>
</body>
</html>