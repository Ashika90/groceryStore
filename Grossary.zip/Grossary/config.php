<?php
 $db_name = "mysql:host=localhost;dbname=grocery";  
 $user="root";
$password="";

 $conn = new PDO($db_name,$user,$password);  
 //if(mysqli_connect_errno()) {  
   //  die("Failed to connect with MySQL: ". mysqli_connect_error());  
 //}
?>